import psycopg2
import os
from psycopg2 import DatabaseError


def get_connection():
    try:
        # Obtiene el string de conexión almacenado en la variable de entorno
        cx_string = os.environ.get('CONNECTION_URL')
        if not cx_string:
            raise ValueError(
                "La variable de entorno CONNECTION_URL no está configurada")
        # Establece la conexión con la base de datos
        cx = psycopg2.connect(cx_string)
        return cx
    except DatabaseError as ex:
        raise ex
    except Exception as ex:
        raise ex
