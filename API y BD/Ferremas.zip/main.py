from flask import Flask
from flask_cors import CORS
from routes import productos, usuario

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    return 'API Ferremas'

# Register blueprints
app.register_blueprint(productos.main, url_prefix="/api/productos")
app.register_blueprint(usuario.main, url_prefix="/api/usuarios")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=81)