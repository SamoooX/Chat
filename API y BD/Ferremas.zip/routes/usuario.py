from flask import Blueprint, jsonify, request
from models.UsuarioModel import UsuariosModel
from models.entities.usuario import Usuario

main = Blueprint("usuarios_blueprint", __name__)

#Registrar usuario

@main.route("/register", methods=['POST'])
def register_usuario():
    try:
        # Verificar si se proporcionó JSON en la solicitud
        if request.json is None:
            return jsonify({"msg": "No JSON data provided"}), 400

        # Depurar el contenido de request.json
        print("Contenido de request.json:", request.json)

        # Verificar si las claves requeridas están presentes en el JSON
        if 'Nombre' not in request.json or 'Correo' not in request.json or 'Contrasena' not in request.json or 'Rol' not in request.json:
            return jsonify({"msg": "Missing required fields in JSON"}), 400

        # Obtener los datos del JSON
        nombre = request.json['Nombre']
        correo = request.json['Correo']
        contrasena = request.json['Contrasena']
        rol = request.json['Rol']

        # Crear el nuevo usuario
        nuevo_usuario = Usuario(None, nombre, correo, contrasena, rol)

        # Registrar el usuario en la base de datos
        if UsuariosModel.registrar_usuario(nuevo_usuario) == 1:
            return jsonify({"msg": "Usuario registrado"}), 201
        else:
            return jsonify({"msg": "Error al registrar el usuario"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500

#Logear usuario

@main.route("/login", methods=['POST'])
def login_usuario():
    try:    
        correo = request.json['Correo']
        contrasena = request.json['Contrasena']
        usuario = UsuariosModel.autenticar_usuario(correo, contrasena)
        if usuario:
            return jsonify(usuario)
        else:
            return jsonify({"msg": "Correo o contraseña incorrectos"}), 401
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500

#Obtener usuario

@main.route("/<int:usuario_id>", methods=['GET'])
def get_usuario(usuario_id):
    try:
        usuario = UsuariosModel.get_usuario(usuario_id)
        if usuario:
            
            usuario_dict = {
                "UsuarioID": usuario.id,
                "Nombre": usuario.nombre,
                "Correo": usuario.correo,
                "Rol": usuario.rol
            }
            return jsonify(usuario_dict)
        else:
            return jsonify({"msg": "Usuario no encontrado"}), 404
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500