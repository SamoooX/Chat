from flask import Blueprint, jsonify, request

from models.entities.productos import Productos
from models.ProductosModel import ProductosModel

main = Blueprint("productos_blueprint", __name__)


# Obtener productos
@main.route("/", methods=['GET'])
def getProductos():
    try:
        productos = ProductosModel.getProductos()
        return jsonify(productos)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Agregar productos
@main.route("/add", methods=['POST'])
def agregar_productos():
    try:
        # Verificar si se proporcionó JSON en la solicitud
        if request.json is None:
            return jsonify({"msg": "No JSON data provided"}), 400

        # Depurar el contenido de request.json
        print("Contenido de request.json:", request.json)

        # Verificar si las claves requeridas están presentes en el JSON
        required_keys = ['nombre', 'descripcion', 'marca', 'categoria', 'precio', 'stock_total']
        for key in required_keys:
            if key not in request.json:
                return jsonify({"msg": f"Missing required field '{key}' in JSON"}), 400

        # Obtener los datos del JSON
        nombre = request.json['nombre']
        descripcion = request.json['descripcion']
        marca = request.json['marca']
        categoria = request.json['categoria']
        precio = float(request.json['precio'])
        stock_total = int(request.json['stock_total'])

        # Crear el nuevo producto
        nuevo = Productos(None, nombre, descripcion, marca, categoria, precio, stock_total)

        # Registrar el producto en la base de datos
        if ProductosModel.add_productos(nuevo) == 1:
            return jsonify({"msg": "Producto agregado"}), 201
        else:
            return jsonify({"msg": "Error al registrar el producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Actualizar productos
@main.route("/update", methods=['PATCH'])
def actualizar_productos():
    try:
        id = request.json['id']
        nombre = request.json['nombre']
        descripcion = request.json['descripcion']
        marca = request.json['marca']
        categoria = request.json['categoria']
        precio = request.json['precio']
        stock_total = request.json['stock_total']
        producto = Productos(id, nombre, descripcion, marca, categoria,  precio,
                             stock_total)
        if ProductosModel.update_productos(producto) == 1:
            return jsonify({"msg": "Producto actualizado"})
        else:
            return jsonify({"msg": "Error al actualizar el producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Eliminar productos
@main.route("/delete/<id_producto>", methods=['DELETE'])
def eliminar_productos(id_producto):
    try:
        if ProductosModel.delete_productos(id_producto) == 1:
            return jsonify({"msg": "Producto eliminado"})
        else:
            return jsonify({"msg": "Error al eliminar el producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Obtener productos por categoría
@main.route("/categoria/<categoria>")
def get_productos_por_categoria(categoria):
    try:
        productos = ProductosModel.getProductosPorCategoria(categoria)
        return jsonify(productos)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Historial de precios
@main.route("/historial_precios/<id_producto>")
def get_historial_precios(id_producto):
    try:
        historial_precios = ProductosModel.getHistorialPrecios(id_producto)
        return jsonify(historial_precios)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Verificar disponibilidad en sucursales
@main.route("/disponibilidad_sucursales/<id_producto>")
def get_disponibilidad_sucursales(id_producto):
    try:
        disponibilidad = ProductosModel.getDisponibilidadSucursales(
            id_producto)
        return jsonify(disponibilidad)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Obtener productos en promoción
@main.route("/promocion")
def get_productos_promocion():
    try:
        productos = ProductosModel.getProductosPromocion()
        return jsonify(productos)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Obtener lanzamientos recientes
@main.route("/lanzamientos")
def get_lanzamientos_recientes():
    try:
        productos = ProductosModel.getLanzamientosRecientes()
        return jsonify(productos)
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500




#agregar Promoción de productos
@main.route("/promocion/agregar", methods=['POST'])
def agregar_producto_promocion():
    try:
        # Verificar si se proporcionó JSON en la solicitud
        if request.json is None:
            return jsonify({"msg": "No JSON data provided"}), 400

        # Verificar si las claves requeridas están presentes en el JSON
        required_keys = ['producto_id', 'fecha_inicio', 'fecha_fin']
        for key in required_keys:
            if key not in request.json:
                return jsonify({"msg": f"Missing required field '{key}' in JSON"}), 400

        # Obtener los datos del JSON
        producto_id = request.json['producto_id']
        fecha_inicio = request.json['fecha_inicio']
        fecha_fin = request.json['fecha_fin']

        # Crear la nueva promoción de producto
        nueva_promocion = {
            "producto_id": producto_id,
            "fecha_inicio": fecha_inicio,
            "fecha_fin": fecha_fin
        }

        # Registrar la promoción de producto en la base de datos
        if ProductosModel.add_producto_promocion(nueva_promocion) == 1:
            return jsonify({"msg": "Promoción de producto agregada"}), 201
        else:
            return jsonify({"msg": "Error al agregar la promoción de producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Actualizar promoción de producto
@main.route("/promocion/actualizar", methods=['PATCH'])
def actualizar_producto_promocion():
    try:
        # Verificar si se proporcionó JSON en la solicitud
        if request.json is None:
            return jsonify({"msg": "No JSON data provided"}), 400

        # Verificar si las claves requeridas están presentes en el JSON
        required_keys = ['producto_id', 'fecha_inicio', 'fecha_fin', 'promocion_id']
        for key in required_keys:
            if key not in request.json:
                return jsonify({"msg": f"Missing required field '{key}' in JSON"}), 400

        # Obtener los datos del JSON
        producto_id = request.json['producto_id']
        fecha_inicio = request.json['fecha_inicio']
        fecha_fin = request.json['fecha_fin']
        promocion_id = request.json['promocion_id']

        # Actualizar la promoción de producto en la base de datos
        if ProductosModel.update_producto_promocion(producto_id, fecha_inicio, fecha_fin, promocion_id) == 1:
            return jsonify({"msg": "Promoción de producto actualizada"}), 200
        else:
            return jsonify({"msg": "Error al actualizar la promoción de producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500


# Eliminar promoción de producto
@main.route("/promocion/eliminar/<int:promocion_id>", methods=['DELETE'])
def eliminar_producto_promocion(promocion_id):
    try:
        if ProductosModel.delete_producto_promocion(promocion_id) == 1:
            return jsonify({"msg": "Promoción de producto eliminada"}), 200
        else:
            return jsonify({"msg": "Error al eliminar la promoción de producto"}), 500
    except Exception as ex:
        return jsonify({"msg": str(ex)}), 500
