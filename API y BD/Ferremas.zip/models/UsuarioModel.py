import bcrypt

from database.db import get_connection
from models.entities.usuario import Usuario


class UsuariosModel:

    @classmethod

    #Obtener usuario de la base de datos
    def get_usuario(self, usuario_id):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT UsuarioID, Nombre, Correo, Rol FROM Usuario WHERE UsuarioID = %s",
                    (usuario_id, ))
                row = cursor.fetchone()
                if row:
                    usuario = Usuario(row[0], row[1], row[2], None, row[3])
                    return usuario
            cx.close()
        except Exception as ex:
            raise Exception(ex)
        return None

    @classmethod
    def registrar_usuario(self, usuario):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                correo = usuario.correo[:100]
                hashed_password = bcrypt.hashpw(
                    usuario.contrasena.encode('utf-8'), bcrypt.gensalt())
                cursor.execute(
                    "INSERT INTO Usuario ( Nombre, Correo, Contrasena, Rol) VALUES (%s, %s, %s, %s)",
                    (usuario.nombre, correo, hashed_password, usuario.rol))
                cx.commit()
                affected_rows = cursor.rowcount
            cx.close()
            return affected_rows
        except Exception as ex:
            raise Exception(ex)

    #Autenticar usuario
    @classmethod
    def autenticar_usuario(self, correo, contrasena):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT UsuarioID, Nombre, Correo, Contrasena, Rol FROM Usuario WHERE Correo = %s",
                    (correo, ))
                row = cursor.fetchone()
                if row and bcrypt.checkpw(contrasena.encode('utf-8'),
                                          row[3].encode('utf-8')):
                    usuario = Usuario(row[0], row[1], row[2], None, row[4])
                    return usuario
            cx.close()
        except Exception as ex:
            raise Exception(ex)
        return None
