class ProductoPromocion:

  def __init__(self, promocion_id, producto_id, fecha_inicio, fecha_fin):
    
    self.promocion_id = promocion_id
    self.producto_id = producto_id
    self.fecha_inicio = fecha_inicio
    self.fecha_fin = fecha_fin


  def to_JSON(self):
    return{
      'promocion_id' : self.promocion_id,
      'producto_id' : self.producto_id,
      'fecha_inicio' : self.fecha_inicio,
      'fecha_fin' : self.fecha_fin
    }