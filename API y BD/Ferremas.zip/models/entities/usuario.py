class Usuario:
  def __init__(self, id, nombre, correo, contrasena, rol):
    self.id = id
    self.nombre = nombre
    self.correo = correo
    self.contrasena = contrasena
    self.rol = rol


def to_JSON(self):
  return{
    'UsuarioID': self.id,
    'Nombre': self.nombre,
    'Correo': self.correo,
    'Rol': self.rol
  }

