class Productos:

    def __init__(self, id, nombre, descripcion, marca, categoria, precio,
                 stock_total):
        self.id = id
        self.nombre = nombre
        self.descripcion = descripcion
        self.marca = marca
        self.categoria = categoria
        self.precio = precio
        self.stock_total = stock_total

    def to_JSON(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'descripcion': self.descripcion,
            'marca': self.marca,
            'categoria': self.categoria,
            'precio': self.precio,
            'stock_total': self.stock_total,
            'historial_precios': [],
            'disponibilidad_sucursales': []
        }
