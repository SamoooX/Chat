from database.db import get_connection
from models.entities.productos import Productos
from models.entities.productoPromocion import ProductoPromocion


class ProductosModel():

    # Obtener productos
    @classmethod
    def getProductos(cls):
        try:
            cx = get_connection()
            productos = []
            with cx.cursor() as cursor:
                cursor.execute("SELECT * FROM Producto")
                rs = cursor.fetchall()
                for row in rs:
                    producto = Productos(row[0], row[1], row[2], row[3],
                                         row[4], row[5], row[6])
                    productos.append(producto.to_JSON())
            cx.close()
            return productos
        except Exception as ex:
            raise Exception(ex)

    # Agregar productos
    @classmethod
    def add_productos(cls, producto):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO Producto (Nombre, Descripcion, MarcaID, CategoriaID, Precio, StockTotal) VALUES (%s, %s, %s, %s, %s, %s)",
                    (producto.nombre, producto.descripcion, producto.marca,
                     producto.categoria, producto.precio,
                     producto.stock_total))
                affected_rows = cursor.rowcount
                cx.commit()
                return affected_rows
        except Exception as ex:
            raise Exception(ex)

    # Actualizar productos
    @classmethod
    def update_productos(self, producto):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "UPDATE Producto SET Nombre = %s, Descripcion = %s, MarcaID = %s, CategoriaID = %s, Precio = %s, StockTotal = %s WHERE ProductoID = %s",
                    (producto.nombre, producto.descripcion, producto.marca,
                     producto.categoria, producto.precio, producto.stock_total,
                     producto.id))
                cx.commit()
                affected_rows = cursor.rowcount
                return affected_rows
            cx.close()
        except Exception as ex:
            raise Exception(ex)

    # Eliminar productos
    @classmethod
    def delete_productos(self, id_producto):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute("DELETE FROM Producto WHERE ProductoID = %s",
                               (id_producto, ))
                affected_rows = cursor.rowcount
                cx.commit()
                cx.close()
                return affected_rows
        except Exception as ex:
            raise Exception(ex)

    # Obtener productos por categoría
    @classmethod
    def getProductosPorCategoria(self, categoria):
        try:
            cx = get_connection()
            productos = []
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT p.ProductoID, p.Nombre, p.Precio, p.Descripcion, c.Nombre, m.Nombre FROM Producto p JOIN Categoria c ON p.CategoriaID = c.CategoriaID JOIN Marca m ON p.MarcaID = m.MarcaID WHERE c.CategoriaID = %s ORDER BY p.Nombre",
                    (categoria, ))
                rs = cursor.fetchall()
                for row in rs:
                    producto = Productos(row[0], row[1], row[2], row[3],
                                         row[4], row[5], [6])
                    productos.append(producto.to_JSON())
            cx.close()
            return productos
        except Exception as ex:
            raise Exception(ex)

    @classmethod
    def getHistorialPrecios(self, id_producto):
        try:
            cx = get_connection()
            historial_precios = []
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT FechaModificacion, Precio FROM HistorialPrecio WHERE ProductoID = %s ORDER BY FechaModificacion",
                    (id_producto, ))
                rs = cursor.fetchall()
                for row in rs:
                    historial_precios.append({
                        'Fecha': row[0],
                        'Valor': row[1]
                    })
            cx.close()
            return historial_precios
        except Exception as ex:
            raise Exception(ex)

    # Verificar disponibilidad en sucursales
    @classmethod
    def getDisponibilidadSucursales(self, id_producto):
        try:
            cx = get_connection()
            disponibilidad = []
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT s.Nombre, ss.Cantidad FROM StockSucursal ss JOIN Sucursal s ON ss.SucursalID = s.SucursalID WHERE ss.ProductoID = %s",
                    (id_producto, ))
                rs = cursor.fetchall()
                for row in rs:
                    disponibilidad.append({
                        'Sucursal': row[0],
                        'Cantidad': row[1]
                    })
            cx.close()
            return disponibilidad
        except Exception as ex:
            raise Exception(ex)

    # Obtener productos en promoción
    @classmethod
    def getProductosPromocion(cls):
        try:
            cx = get_connection()
            promociones = []
            with cx.cursor() as cursor:
                cursor.execute("SELECT * FROM ProductoPromocion")
                rs = cursor.fetchall()
                for row in rs:
                    promocion = {
                        'promocion_id': row[0],
                        'producto_id': row[1],
                        'fecha_inicio': row[2],
                        'fecha_fin': row[3]
                    }
                    promociones.append(promocion)
            cx.close()
            return promociones
        except Exception as ex:
            raise Exception(ex)

    # Obtener lanzamientos recientes
    @classmethod
    def getLanzamientosRecientes(self):
        try:
            cx = get_connection()
            productos = []
            with cx.cursor() as cursor:
                cursor.execute(
                    "SELECT p.ProductoID, p.Nombre, p.Precio, p.Descripcion, c.Nombre, m.Nombre FROM ProductoLanzamiento pl JOIN Producto p ON pl.ProductoID = p.ProductoID JOIN Categoria c ON p.CategoriaID = c.CategoriaID JOIN Marca m ON p.MarcaID = m.MarcaID ORDER BY p.Nombre"
                )
                rs = cursor.fetchall()
                for row in rs:
                    producto = Productos(row[0], row[1], row[2], row[3],
                                         row[4], row[5], [6])
                    productos.append(producto.to_JSON())
            cx.close()
            return productos
        except Exception as ex:
            raise Exception(ex)

    #Agregar promoción de productos
    @classmethod
    def add_producto_promocion(cls, promocion):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO ProductoPromocion (ProductoID, FechaInicio, FechaFin) VALUES (%s, %s, %s)",
                    (promocion['producto_id'], promocion['fecha_inicio'],
                     promocion['fecha_fin']))
                affected_rows = cursor.rowcount
                cx.commit()
                return affected_rows
        except Exception as ex:
            raise Exception(ex)

    @classmethod
    def update_producto_promocion(cls, producto_id, fecha_inicio, fecha_fin,
                                  promocion_id):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "UPDATE ProductoPromocion SET ProductoID = %s, FechaInicio = %s, FechaFin = %s WHERE PromocionID = %s",
                    (producto_id, fecha_inicio, fecha_fin, promocion_id))
                affected_rows = cursor.rowcount
                cx.commit()
                return affected_rows
        except Exception as ex:
            raise Exception(ex)

    #Eliminar promoción de productos
    @classmethod
    def delete_producto_promocion(cls, promocion_id):
        try:
            cx = get_connection()
            with cx.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM ProductoPromocion WHERE PromocionID = %s",
                    (promocion_id, ))
                affected_rows = cursor.rowcount
                cx.commit()
                return affected_rows
        except Exception as ex:
            raise Exception(ex)
